from sdc_consul.base import ConsulClient
